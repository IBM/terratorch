# import so they get registered
from terratorch.models.backbones.prithvi_swin import MMSegSwinTransformer
from terratorch.models.backbones.prithvi_vit import TemporalViTEncoder

__all__ = ("TemporalViTEncoder", "MMSegSwinTransformer")
__all__ = ("TemporalViTEncoder", "MMSegSwinTransformer")
__all__ = ("TemporalViTEncoder", "MMSegSwinTransformer")
