# register models with timm
import terratorch.models
from terratorch.models.backbones import *  # noqa: F403
